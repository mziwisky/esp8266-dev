#ifndef __ADC_H__
#define __ADC_H__

uint16 adc_read(void);

#endif
