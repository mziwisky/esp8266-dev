/* 
 * copyright (c) 2008 - 2012 Espressif System 
 * 
 * esf buffer data structure
 */

#ifndef _ESF_BUF_H_
#define _ESF_BUF_H_

#define EP_OFFSET       36  /* see comments in pbuf.h */

#endif /* _ESF_BUF_H_ */
